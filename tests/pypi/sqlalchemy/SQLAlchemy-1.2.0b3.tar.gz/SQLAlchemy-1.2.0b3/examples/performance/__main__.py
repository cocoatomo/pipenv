"""Allows the examples/performance package to be run as a script."""

from . import Profiler

if __name__ == '__main__':
    Profiler.main()

